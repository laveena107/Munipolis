package com.example.problem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.jackandphantom.androidlikebutton.AndroidLikeButton;

public class upvote extends AppCompatActivity {
    private int CurrentProgress =0;
    private ProgressBar pb,pb2,pb3,pb4,pb5;
    private Button b,b2,b3,b4,b5;

    AndroidLikeButton like;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_upvote);
        pb=findViewById(R.id.pb);
        like=findViewById(R.id.likebtn);
        b=findViewById(R.id.btn);
        pb2=findViewById(R.id.pb2);
        b2=findViewById(R.id.btn2);
        pb3=findViewById(R.id.pb3);
        b3=findViewById(R.id.btn3);
        pb4=findViewById(R.id.pb4);
        b4=findViewById(R.id.btn4);
        pb5=findViewById(R.id.pb5);
        b5=findViewById(R.id.btn5);

        like.setOnLikeEventListener(new AndroidLikeButton.OnLikeEventListener() {
            @Override
            public void onLikeClicked(AndroidLikeButton androidLikeButton) {
                Toast.makeText(upvote.this,"Voted",Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onUnlikeClicked(AndroidLikeButton androidLikeButton) {


            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress + 55;
                pb.setProgress(CurrentProgress);
                pb.setMax(100);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress + 25;
                pb2.setProgress(CurrentProgress);
                pb2.setMax(100);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress + 35;
                pb3.setProgress(CurrentProgress);
                pb3.setMax(100);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress + 55;
                pb4.setProgress(CurrentProgress);
                pb4.setMax(100);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress + 65;
                pb5.setProgress(CurrentProgress);
                pb5.setMax(100);
            }
        });

    }
}