package com.example.problem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.w3c.dom.Text;

public class Dashboard extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    TextView t,t1,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        t=(TextView)findViewById(R.id.textView14);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Dashboard.this, status.class);
                startActivity(intent);
            }
        });
        t1=(TextView)findViewById(R.id.textView15);
        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Dashboard.this, nearby.class);
                startActivity(intent1);
            }
        });
        t2=(TextView)findViewById(R.id.textView16);
        t2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Dashboard.this, upvote.class);
                startActivity(intent2);
            }
        });
        bottomNavigationView= findViewById(R.id.bottom_navigator);

        bottomNavigationView.setSelectedItemId(R.id.home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId())
                {
                    case R.id.Locate:
                        startActivity(new Intent(getApplicationContext(), Locate.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(), home.class));
                        overridePendingTransition(0,0);
                        return true;


                    case R.id.dashboard:

                        return true;

                    case R.id.notify:
                        startActivity(new Intent(getApplicationContext(),Notify.class));
                        overridePendingTransition(0,0);
                        return true;
                }


                return false;
            }
        });
    }
}