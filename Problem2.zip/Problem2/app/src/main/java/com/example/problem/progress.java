package com.example.problem;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ProgressBar;


public class progress extends AppCompatActivity {
    private int CurrentProgress =0;
    private ProgressBar pb;
    private Button b,b1,b2,b3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_progress);
        pb=findViewById(R.id.progressBar);
        b=findViewById(R.id.button12);
        b1=findViewById(R.id.button13);
        b2=findViewById(R.id.button14);
        b3=findViewById(R.id.button15);


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress +31;
                pb.setProgress(CurrentProgress);
                pb.setMax(100);
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress +31;
                pb.setProgress(CurrentProgress);
                pb.setMax(100);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress +31;
                pb.setProgress(CurrentProgress);
                pb.setMax(100);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CurrentProgress = CurrentProgress +31;
                pb.setProgress(CurrentProgress);
                pb.setMax(100);
            }
        });


        

    }
}